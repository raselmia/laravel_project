@extends('layouts.layoutadmin')

@section('title', 'Talents Associates | Admin Dashboard')

@section('content')

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->

<div class="row">
	
	<div class="col-md-12 ">
		<h5 class="jumbotron">Welcome {{ Auth::user()->name }}</h5>
		<h6>You Can manage Your Website From Here!!!!</h6>
		</div>
		</div>
		<div clas="row">
		
		
				<div class="col-sm-12">
	
	
	
	</div>

		</div>

@endsection