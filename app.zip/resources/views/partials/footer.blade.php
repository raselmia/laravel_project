<footer>
	<div class="container">
		<div class="row">
			
			<div class="col-lg-4">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>Talents Associates </strong><br>
					Meherba Plaza, Level-12, Suite # NP  <br>
					 33 Topkhana Road, Dhaka-1000, Bangladesh <br>
						<i class="fa fa-phone" aria-hidden="true"></i> 01715-219900, 01615-219900 <br>
						<i class="fa fa-envelope-o" aria-hidden="true"></i>&nbspibrahimkhan1965@yahoo.com
					</address>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="widget">
					<h5 class="widgetheading">Important Links</h5>
					<ul class="link-list">
						
						<li><a href="http://www.supremecourt.gov.bd" target="empty">Supreme Court of Bangladesh</a></li>
						<li><a href="http://www.dsebd.org/" target="empty">Dhaka Stock Exchange Ltd</a></li>
						<li><a href="http://bdt.fxexchangerate.com" target="empty">Foreign Exchange Rate Bangladesh</a></li>
						<li><a href="http://www.barcouncil.gov.bd" target="empty">Bangladesh Bar Council</a></li>
						<li><a href="http://www.ec.org.bd" target="empty">Bangladesh Election Commission</a></li>
						<li><a href="http://www.acc.org.bd/" target="empty">Bangladesh Anti-corruption Commission</a></li>
						
					</ul>
				</div>
			</div>
			<div class="col-lg-4">
			<div class="widget">
					<h5 class="widgetheading">Quick Links</h5>
					<ul class="link-list">
						
						<li><a href="http://www.supremecourt.gov.bd" target="empty">Supreme Court of Bangladesh</a></li>
						<li><a href="http://www.dsebd.org/" target="empty">Dhaka Stock Exchange Ltd</a></li>
						<li><a href="http://bdt.fxexchangerate.com" target="empty">Foreign Exchange Rate Bangladesh</a></li>
						<li><a href="http://www.barcouncil.gov.bd" target="empty">Bangladesh Bar Council</a></li>
						<li><a href="http://www.ec.org.bd" target="empty">Bangladesh Election Commission</a></li>
						<li><a href="http://www.acc.org.bd/" target="empty">Bangladesh Anti-corruption Commission</a></li>
						
					</ul>
				</div>
					
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Talents Associates 2016 All right reserved. By </span><a href="http://arksit.com" target="_blank">Arks IT</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="https://www.facebook.com" data-placement="top" target="empty" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://www.twitter.com" data-placement="top" target="empty" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https://www.linkedin.com" data-placement="top" target="empty" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="https://www.pinterest.com" data-placement="top" target="empty" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="https://plus.google.com" data-placement="top" target="empty" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>