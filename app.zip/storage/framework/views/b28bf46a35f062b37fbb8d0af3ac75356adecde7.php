<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            <i class="fa fa-dashboard"></i> Add Notice Here
        </li>
    </ol>
</div>
</div>
<!-- /.row -->



<!-- /.row -->

<div class="row">
<div class="col-md-2"></div>
<div class="col-lg-8" >
    <?php echo Form::model($review,['route'=>['review.update',$review->id],'method'=>'PUT']); ?>

        <div class="row">
            <div class="col-md-12">
                <br/>
                <?php echo Form::label('client_name', 'Client Name'); ?>

                <?php echo Form::text('client_name', null,array('class' => 'form-control','placeholder'=>'Add Client Name Here', 'required' => 'required','max'=>'300')); ?>

            </div>
              <div class="col-md-12">
                <br/>
                <?php echo Form::label('review', 'Review:'); ?>

                <?php echo Form::text('review', null,array('class' => 'form-control', 'placeholder'=>'Add User Review Here', 'required' => 'required')); ?>

            </div>
            
            <div class="col-md-12">
                <br/>
                <button type="submit" class="btn btn-success">Update</button>
               
            </div>
        </div>
    <?php echo Form::close(); ?>

</div>
</div>

<!-- /.row -->


</div>
<!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>