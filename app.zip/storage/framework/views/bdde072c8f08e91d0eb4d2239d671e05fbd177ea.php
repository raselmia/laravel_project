<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    <ol class="breadcrumb">
        
             Review
      
    </ol>
</div>
</div>
<div class="row">
     <div  class="col-md-8 col-md-offset-2">
     <h1>Review</h1>
         <hr>
   
       </div>
       </div>
       <div class="row">
   	
<div class="col-md-8 col-md-offset-2">

	<h2><strong>Client Name:</strong><?php echo e($review->client_name); ?></h2>
	<p><strong>Review:</strong><?php echo e($review->review); ?></p>

<hr>
</div>
<div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>