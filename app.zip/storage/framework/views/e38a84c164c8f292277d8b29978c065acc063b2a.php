<?php session_start();
?>


<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    </div>
    </div>
    <div class="row">
<div class="col-lg-12">
    <?php if(isset($_SESSION['status'])): ?>
    <p class="alert alert-success"><?php echo e($_SESSION['status']); ?></p>
    <?php session_unset('status');?>
    </div>
    </div>
    <?php endif; ?>
    <div class="breadcrumb">
     
            Review list
       
   
</div>

<div class="row">
	
	<div class="col-md-12">
		<table class="table table-bordered">
			<tr>
			   <th>Serial No</th>
				<th>Client Name</th>
				<th>Review</th>
				<th>Action</th>
			</tr>
			<?php $slNo = 1; ?>
			<?php foreach($reviews as $review): ?>
				<tr>
					<td><?php echo e($slNo++); ?></td>
					<td><?php echo e($review->client_name); ?></td>
					<td><?php echo e($review->review); ?></td>
					<td>
						
								<a href="<?php echo e(route('review.show',$review->id)); ?>" class="btn btn-success">View</a>
						
							
								<a href="<?php echo e(route('review.edit',$review->id)); ?>" class="btn btn-primary">Edit</a>
						
														
						<?php echo Form::open(array('method'=>'DELETE','route'=>array('review.destroy',$review->id))); ?>


                        <?php echo Form::submit('Delete', array('class'=>'btn btn-danger','onclick' => 'return confirm("Are you sure want to Delete?");')); ?>

                        <?php echo Form::close(); ?>

						
                       
					
						


					</td>
				</tr>
			<?php endforeach; ?>


		</table>
		</div>
		</div>
	<?php /* <div>
		<?php echo $notice->links();; ?>


	</div> */ ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>