<?php 
session_start();

?>



<?php $__env->startSection('title', 'Talents Assciates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Talents Assciates 
                        </h1>
                        </div>
                        </div>

                   <div class="row" >
						<div class="col-md-12">
						   
						   <?php if(isset($_SESSION['status'])): ?>
						   <p class="alert alert-success"><?php echo e($_SESSION['status']); ?></p>
						   <?php session_unset('status'); ?>
						  
						  <?php endif; ?>
						  </div>
						  </div>

                        </div>
                        <div>

                        <div class="breadcrumb">
                            <li class="active">
                             Update Your Profile Here
                            </li>
                        </div>
                  </div>
                <!-- /.row -->


                
                <!-- /.row -->

                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-lg-8" >
                        <?php echo Form::model($about,['route'=>['profile.update',$about->id],'method'=>'put','files' => true]); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <br/>
                                    <?php echo Form::label('name', 'Name:'); ?>

                                    <?php echo Form::text('name', null,array('class' => 'form-control','placeholder'=>'Enter Your  Name', 'required' => 'required')); ?>

                                </div>
                                <div class="col-md-12">
                                    <br/>
                                    <?php echo Form::label('actor', 'Company Role:'); ?>

                                   <?php echo Form::select('actor', array('select'=>'select','Lead Consultant' => 'Lead Consultant','Associates' => 'Associates')
                                 
                            );; ?>

                                    
                                </div>
                                <div class="col-md-12">
                                    <br/>
                                    <?php echo Form::label('details', 'Desingnation:'); ?>

                                    <?php echo Form::textarea('details', null,array('class' => 'form-control','placeholder'=>'Add Details Article', 'required' => 'required')); ?>

                                    
                                </div>
                                <div class="col-md-12">
                                    <br/>
                                    <?php echo Form::label('image', 'Profile Image:'); ?>

                                    <?php echo Form::file('image', array('class' => 'image')); ?>

                                </div>
                                <div class="col-md-12">
                                    <br/>
                                    <button type="submit" class="btn btn-success"> Update Article</button>
                                    <button type="reset" class="btn btn-success">Reset</button>
                                </div>
                            </div>
                        
                        <?php echo Form::close(); ?>

                    </div>
                </div>
                
                <!-- /.row -->


            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>