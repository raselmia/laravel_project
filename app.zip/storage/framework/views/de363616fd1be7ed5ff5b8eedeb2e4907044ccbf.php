<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

       <div class="row">
   	
<div class="col-md-8 col-md-offset-2">
<img src="<?php echo e(URL::asset('/thumbnails/'.$article->image)); ?>" alt="profile Pic" height="300">
	<h2><strong><?php echo e($article->title); ?></strong></h2>
  <p><strong><?php echo e($article->details); ?></strong>
  </p>
	</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>