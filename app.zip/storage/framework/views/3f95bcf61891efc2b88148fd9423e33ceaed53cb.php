<?php $__env->startSection('title', 'Talents Associates | About Us'); ?>

<?php $__env->startSection('content'); ?>

	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">About Us</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<div class="container">
					
					<div class="about">
					
						<div class="row"> 
							<div class="col-md-4">
								<h4 class="widgetheading">Lead Consultant</h4>
					<address>
					<strong>TA N M Ibrahim Khan    </strong><br>
					M.Com(Fin), MBA(HRM), PGDPM (1st class)<br> 
                    LL.B(CU), LL.M(PUB), ITP, CA(CC), FIPM <br>
                     Trained on ISO 9001: 2008

                        </address>
				</div> 
							<div class="col-md-4">
								<h4 class="widgetheading">Associates</h4>
					<address>
					<strong>Advocate M. A. Taher <br>
   								 </strong>
   								 <p>M.Com (Acct), LL.B, CA(ICC)</p>

                        </address>
				</div>
								<div class="col-md-4">
								<h4 class="widgetheading">Associates</h4>
					<address>
					<strong>Advocate M. Yasmin
   								 </strong><br>
   								  <p>LLB (Hon), LLM (DU), DGDHRM,<br>
   								  	PGD-Compliance Mgt., AIPM
   								   </p>


                        </address>
				</div>
							
							</div>
						</div>
						
						
				<div class="about">
					
						<div class="row"> 
							<div class="col-md-4">
								<h4 class="widgetheading">Associates</h4>
					<address>
								<strong>
									M. S. Hussain
  												 </strong><br>

					<p>MBA (HRM), PGDPM, FIPM</p>

                        </address>
				</div> 
							<div class="col-md-4">
								<h4 class="widgetheading">Associates</h4>
					<address>
					<strong>M. K. Hasan Chowdhury <br>
   								 </strong>
   								 <p>M.Com(Acctt), MBA(Fin), CA(CC)</p>

                        </address>
				</div>
								<div class="col-md-4">
								<h4 class="widgetheading">Associates</h4>
					<address>
					<strong>Md. Iqbal Bahar Khan
   								 </strong><br>
   								  <p>M.Com (Mgt), MBA, PGDHRM, LL.B, MIPM<br>
   								  	
   								   </p>


                        </address>
				</div>
							
							</div>
						</div>
						<div class="row">
						<div class="col-md-12">
						<p><strong>*</strong>A group of qualified executives and on call Experts are there.  </p>
									
								</div>		
							

						</div>
							<div class="row">
							<div class="col-md-4">
								<h4 class="widgetheading">ADVISORY TEAM</h4>
					<address>
					<strong>Professor Dr. N A Khan, PhD <br>
					M. N Huda Monsury, FCA<br> 
                   M. J. Islam, ACA, Advocate <br>
                     Mansur Ahmed, FCMA <br>
                     M. S. Ali, MBA(HR), PGDPM, FIPM, CAHRI	 </strong>

                        </address>
				</div> 
							
							
						<!-- Our team ends -->
					  
						
					</div>
						
					
						</div>		
				


	</section>
	

<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>