<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    <div>
    <?php echo $__env->make('partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	
    </div>
    <ol class="breadcrumb">
        <li class="active">
            <i class="fa fa-dashboard"></i> Notice list
        </li>
    </ol>
</div>
</div>
<div class="row">
	
	<div class="col-md-12">
		<table class="table table-bordered">
			<tr>
			   <th>id</th>
				<th>Notice Title</th>
				<th>Link</th>
				<th>Action</th>
			</tr>
			<?php $slNo = 1; ?>
			<?php foreach($notice as $notice): ?>
				<tr>
					<td><?php echo e($slNo++); ?></td>
					<td><?php echo e($notice->heading); ?></td>
					<td><?php echo e($notice->link); ?></td>
					<td>
					
								<a href="<?php echo e(route('notice.show',$notice->id)); ?>" class="btn btn-success">View</a>
						
						
								<a href="<?php echo e(route('notice.edit',$notice->id)); ?>" class="btn btn-primary">Edit</a>
						
						
														
						<?php echo Form::open(array('method'=>'DELETE','route'=>array('notice.destroy',$notice->id))); ?>


                        <?php echo Form::submit('Delete', array('class'=>'btn btn-danger','onclick' => 'return confirm("Are you sure want to Delete?");')); ?>

                        <?php echo Form::close(); ?>


					</td>
				</tr>
			<?php endforeach; ?>


		</table>
		</div>
		</div>
	<?php /* <div>
		<?php echo $notice->links();; ?>


	</div> */ ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>