<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->

<div class="row">
	
	<div class="col-md-12 ">
		<h5 class="jumbotron">Welcome <?php echo e(Auth::user()->name); ?></h5>
		<h6>You Can manage Your Website From Here!!!!</h6>
		</div>
		</div>
		<div clas="row">
		
		
				<div class="col-sm-12">
	
	
	
	</div>

		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>