<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            <i class="fa fa-dashboard"></i> Add notice here
        </li>
    </ol>
</div>
</div>
<!-- /.row -->



<!-- /.row -->

<div class="row">
<div class="col-md-2"></div>
<div class="col-lg-8" >
    <?php echo Form::open(array('route' => 'notice.store','enctype' => 'multipart/form-data')); ?>

        <div class="row">
            <div class="col-md-12">
                <br/>
                <?php echo Form::label('heading', 'Heading:'); ?>

                <?php echo Form::text('heading', null,array('class' => 'form-control','placeholder'=>'Add Title', 'required' => 'required','max'=>'300')); ?>

            </div>
              <div class="col-md-12">
                <br/>
                <?php echo Form::label('link', 'Link:'); ?>

                <?php echo Form::text('link', null,array('class' => 'form-control', 'placeholder'=>'Add Title', 'required' => 'required')); ?>

            </div>
            
            <div class="col-md-12">
                <br/>
                <button type="submit" class="btn btn-success">Add Notice</button>
                <button type="reset" class="btn btn-success">Reset</button>
            </div>
        </div>
    <?php echo Form::close(); ?>

</div>
</div>

<!-- /.row -->


</div>
<!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>