<?php $__env->startSection('title', 'Talents Associates | Welcome'); ?>

<?php $__env->startSection('content'); ?>
	<section id="featured">
	 
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
              <li>
                <img src="<?php echo e(asset('dist/img/slides/1.jpg')); ?>" alt="" />
                <div class="flex-caption">
                    <h3>Awesome Design</h3> 
					<p>Doloribus omnis minus temporibus perferendis ipsa architecto non, magni quam</p>  
                </div>
              </li>
              <li>
                <img src="<?php echo e(asset('dist/img/slides/2.jpg')); ?>" alt="" />
                <div class="flex-caption">
                    <h3>Fully Responsive</h3> 
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elitincidunt eius magni provident.</p> 
                </div>
              </li>
              <li>
                <img src="<?php echo e(asset('dist/img/slides/3.jpg')); ?>" alt="" />
                <div class="flex-caption">
                    <h3>Multi-purpose Theme</h3> 
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit donec mer lacinia.</p>  
                </div>
              </li>
            </ul>
        </div>
	<!-- end slider -->
 
	</section>
	<section class="callaction">
	<div class="container">
		<div class="row">
		<div class="col-md-4">
		<img src="<?php echo e(asset('dist/img/people.png')); ?>" alt="" width="100%"/>
		</div>
			<div class="col-md-8">
				<div><h1><span>Hello,<span class="blue_text">Welcome!!</span></span></h1><span class="clear spacer_responsive_hide_mobile " style="height:13px;display:block;"></span><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident, doloribus omnis minus temporibus perferendis nesciunt quam repellendus nulla nemo ipsum odit corrupti consequuntur possimus, vero mollitia velit ad consectetur. Alias, laborum excepturi nihil autem nemo numquam, ipsa architecto non, magni consequuntur quam.</p>
				<p>Perferendis nesciunt quam repellendus nulla nemo ipsum odit corrupti consequuntur possimus, vero mollitia quam repellendus nulla nemo ipsum odit corrupti consequuntur possimus, vero mollitia velit ad consectetur.</p>
				</div>
			</div>
		</div>
		
	</div>
	</section>
	<section id="content">
	
	
	<div class="container">
		
	     <div class="row">
							<div class="col-md-8">
								<!-- Heading and para -->
								<div class="block-heading-two">
									<h3><span>Articles</span></h3>
								</div>
								 <?php foreach($articles as $article): ?>
								<div>
								<h4> <?php echo e($article->title); ?></h4>
								<p><?php echo e(substr($article->summary, 0, 300)); ?><?php echo e(strlen($article->summary) > 300 ? "..." : ""); ?></p>
								<br><br>
								<a href="<?php echo e(url('article_view/'.$article->id)); ?>" class="btn btn-success pull-right" >Read More </a>
								</div>
								<br><br>
								<?php endforeach; ?>
							</div>
							<div class="col-md-4">
								
								<div class="block-heading-two">
									<h3><span>Our Solution</span></h3>
								</div>		
								<!-- Accordion starts -->
								<div class="panel-group" id="accordion-alt3">
								 <!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
								  <div class="panel">	
									<!-- Panel heading -->
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
											<i class="fa fa-angle-right"></i> Accordion Heading Text Item # 1
										  </a>
										</h4>
									 </div>
									 <div id="collapseOne-alt3" class="panel-collapse collapse">
										<!-- Panel body -->
										<div class="panel-body">
										  Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
										</div>
									 </div>
								  </div>
								  <div class="panel">
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseTwo-alt3">
											<i class="fa fa-angle-right"></i> Accordion Heading Text Item # 2
										  </a>
										</h4>
									 </div>
									 <div id="collapseTwo-alt3" class="panel-collapse collapse">
										<div class="panel-body">
										  Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
										</div>
									 </div>
								  </div>
								  <div class="panel">
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseThree-alt3">
											<i class="fa fa-angle-right"></i> Accordion Heading Text Item # 3
										  </a>
										</h4>
									 </div>
									 <div id="collapseThree-alt3" class="panel-collapse collapse">
										<div class="panel-body">
										  Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
										</div>
									 </div>
								  </div>
								  <div class="panel">
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseFour-alt3">
											<i class="fa fa-angle-right"></i> Accordion Heading Text Item # 4
										  </a>
										</h4>
									 </div>
									 <div id="collapseFour-alt3" class="panel-collapse collapse">
										<div class="panel-body">
										  Sed ut perspiciaatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
										</div>
									 </div>
								  </div>
								</div>
								<!-- Accordion ends -->
								<div class="block-heading-two">
									<h3><span>Notice List</span></h3>
									<div style="height:200px; overflow:scroll;">
									<?php foreach($notices as $notice): ?>
										<h5><a href="<?php echo e($notice->link); ?>" target="_blank"><?php echo e($notice->heading); ?></a></h5>
										<?php endforeach; ?>
										
									</div>
								</div>
								
							</div>
							
					
							
						</div>
	
	
	</div>
	
	</section>
	<div class="testimonial-area">
    <div class="testimonial-solid">
        <div class="container"> 
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active">
                        <a href="#"></a>
                    </li>
                    <?php $Num = 1; ?>
					<?php foreach($reviews as $row): ?>
                    <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($Num++); ?>" class="">
                        <a href="#"></a>
                    </li>
                    <?php endforeach; ?>
                    
                </ol>
                <div class="carousel-inner">
                    <div class="item active">
                        <p>Blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                        <p>
                            <b>- Mark John -</b>
                        </p>
                    </div>
                    <?php foreach($reviews as $review): ?>
                    <div class="item">
                        <p><?php echo e($review->review); ?></p>
                        <p>
                            <b>- <?php echo e($review->client_name); ?> -</b>
                        </p>
                    </div>
                    <?php endforeach; ?>
                  
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>