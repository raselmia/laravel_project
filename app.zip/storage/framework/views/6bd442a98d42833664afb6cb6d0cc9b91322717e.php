<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->

<div class="row">
	
	<div class="col-md-12">
		<h1 id="welcome">Welcome <?php echo e(Auth::user()->name); ?></h1>
		<h3>You Can manage Your Website From Here!!!!</h3>
		</div>
		</div>
	<?php /* <div>
		<?php echo $notice->links();; ?>


	</div> */ ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>