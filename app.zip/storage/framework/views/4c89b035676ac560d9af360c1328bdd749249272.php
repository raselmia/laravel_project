<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo $__env->yieldContent('title'); ?></title>

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="shortcut icon" href="<?php echo e(asset('dist/img/logo.png')); ?>">
<link rel="icon" type="image/png"href="<?php echo e(asset('dist/img/logo.png')); ?>"
<meta name="description" content="" />
<meta name="author" content="" />
<!-- css -->
<link href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('dist/css/fancybox/jquery.fancybox.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('dist/css/flexslider.css')); ?>" rel="stylesheet" />

<link href="<?php echo e(asset('dist/css/style.css ')); ?>" rel="stylesheet" />

<style>
.logo{
	margin-top: -25px;
	height:80px;
	width:auto;
}
</style>
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

<script
        src="http://maps.googleapis.com/maps/api/js">
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>


</head>
<body>
<div id="wrapper">
	<!-- start header -->
	
	<!-- end header -->

    <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->yieldContent('content'); ?>
 <?php echo $__env->make('partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

 



<script src="<?php echo e(asset('dist/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/jquery.fancybox.pack.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/jquery.fancybox-media.js')); ?>"></script> 
<script src="<?php echo e(asset('dist/js/portfolio/jquery.quicksand.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/portfolio/setting.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/jquery.flexslider.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/animate.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>

</body>
</html>