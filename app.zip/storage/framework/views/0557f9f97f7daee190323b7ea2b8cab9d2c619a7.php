    <header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img class="logo" src="<?php echo e(asset('dist/img/logo.png')); ?>" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li> 
						<li><a href="<?php echo e(url('about')); ?>">About Us</a></li>
						<li><a href="<?php echo e(url('service')); ?>">Services</a></li>
                        <li><a href="<?php echo e(url('portfolio')); ?>">Portfolio</a></li>
                        <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                        <!-- <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-user fa-2x"></i></a></li>
                        <?php /*  <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li> */ ?> -->
                    </ul>
                </div>
            </div>
        </div>
	</header>