<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    <ol class="breadcrumb">
       
         Notice
      
    </ol>
</div>
</div>
<div class="row">
     <div  class="col-md-8 col-md-offset-2">
     <h1>Notice</h1>
         <hr>
   
       </div>
       </div>
       <div class="row">
   	
<div class="col-md-8 col-md-offset-2">

	<h2><strong>Notice TitLe:</strong><?php echo e($notice->heading); ?></h2>
	<p><strong>Link:</strong><?php echo e($notice->link); ?></p>

<hr>
</div>
<div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>