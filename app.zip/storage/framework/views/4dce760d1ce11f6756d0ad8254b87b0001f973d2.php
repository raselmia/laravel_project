

<div>
	<h3>Thank You For contact</h3>
</div>


<div>
	<?php echo e($bodyMessage); ?>

</div>

<p>Sent via <?php echo e($email); ?></p>
