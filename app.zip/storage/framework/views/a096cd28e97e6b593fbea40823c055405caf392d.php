<?php $__env->startSection('title', 'Talents Associates | '); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->

</div>
<div class="row">
     <div  class="col-md-8 col-md-offset-2">
     <h1></h1>
    
   
       </div>
       </div>
       <div class="row">
   	
<div class="col-md-8 col-md-offset-2">

<img src="<?php echo e(URL::asset('/thumbnails/'.$article->image)); ?>" alt="Article Picture" height="300">
	<h2><strong><?php echo e($article->title); ?></strong></h2>
  <div class="col-md-">
     <span style="text-align: justify;"><?php echo $article->details; ?></span>
   
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutone', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>