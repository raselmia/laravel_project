<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

       <div class="row">
   	
<div class="col-md-8 col-md-offset-2"> 
<br><br>
<img src="<?php echo e(URL::asset('/thumbnails/thumb_'.$about->image)); ?>" alt="Profile Picture" height="300">
	<h3><?php echo $about->name; ?></h3>
	<h4><?php echo $about->actor; ?></h4>
  <p><strong><?php echo $about->details; ?></strong>
  </p>
	</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>