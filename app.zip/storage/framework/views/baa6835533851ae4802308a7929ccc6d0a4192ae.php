<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            <i class="fa fa-dashboard"></i> 
        </li>
    </ol>
</div>
</div>
<div class="row">
     <div  class="col-md-8 col-md-offset-2">
     <h1></h1>
         <hr>
   
       </div>
       </div>
       <div class="row">
   	
<div class="col-md-8 col-md-offset-2">
<img src="<?php echo e(URL::asset('/thumbnails/'.$article->image)); ?>" alt="profile Pic" height="300">
	<h2><strong><?php echo e($article->title); ?></strong></h2>
  <p><strong><?php echo e($article->details); ?></strong>
  </p>
	
<hr>
</div>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>