<?php $__env->startSection('title', 'Talents Associates | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

<div class="container-fluid">

<!-- Page Heading -->
<div class="row">
<div class="col-lg-12">
    <h1 class="page-header">
        Talents Associates 
    </h1>
   

            <h2 class="breadcrumb">Article list</h2> 
      
   
</div>
</div>
<div class="row">
	
	<div class="col-md-12">
		<table class="table table-bordered">
			<tr>
			   <th>Serial No.</th>
				<th>Title</th>
				<th>Summary</th>
				<th>Image</th>
				<th>Action</th>
			</tr>
			<?php $i=0 ?>
			 <?php foreach($article as $article): ?>
			 <?php $i++ ?>
				<tr>
					<td><?php echo e($i); ?></td>
					<td><?php echo e($article->title); ?></td>
					<td><?php echo e(substr($article->summary, 0, 300)); ?><?php echo e(strlen($article->summary) > 300 ? "..." : ""); ?></td>
					<td><img src="<?php echo e(URL::asset('/thumbnails/'.$article->image)); ?>" alt="profile Pic" height="150"></td>
					<td>
						<a href="<?php echo e(route('article.show',$article->id)); ?>" class="btn btn-success">View</a>
						<a href="<?php echo e(route('article.edit',$article->id)); ?>" class="btn btn-info">Edit</a>
						<?php echo Form::open(array('method'=>'DELETE', 'route'=>array('article.destroy',$article->id))); ?>


                        <?php echo Form::submit('Delete', array('class'=>'btn btn-danger','onclick' => 'return confirm("Are you sure want to Delete?");')); ?>

                <?php echo form::close(); ?>


					</td>
				</tr>
			
			<?php endforeach; ?>
			
		</table>
		</div>
		</div>
	</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>